/*jslint browser: true, devel: true, eqeq: true, plusplus: true, sloppy: true, vars: true, white: true*/
/*eslint-env browser*/
/*eslint 'no-console': 0*/

var button = document.querySelector(".button1");
var getal = document.querySelector(".getal");
var huidiggetal = 0;


console.log(button);


function laatgetalzien() {
    huidiggetal++;
    getal.textContent = huidiggetal;
}

button.addEventListener("click", laatgetalzien);
